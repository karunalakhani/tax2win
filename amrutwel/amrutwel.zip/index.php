 <!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap Min CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!-- Animate Min CSS -->
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <!-- IcoFont Min CSS -->
        <link rel="stylesheet" href="assets/css/icofont.min.css">
        <!-- Swiper Min CSS -->
        <link rel="stylesheet" href="assets/css/swiper.min.css">
        <!-- Magnific Popup Min CSS -->
        <link rel="stylesheet" href="assets/css/magnific-popup.min.css">
        <!-- Style CSS -->
        <link rel="stylesheet" href="assets/css/style.css">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="assets/css/responsive.css">

        <title>Amrutwel - Landing Page</title>

		<link rel="icon" type="image/png" href="assets/img/favicon.png">
       <style>
    @media only screen and (max-width: 700px){
.pooja{
  
    margin-left: 85px;
     margin-top: 20px;
    
}
.pooja1{
  
    margin-left: 70px;
     margin-top: 20px;
    
}

      .float-right .float{
      position:fixed;
   width: 50px;
   height: 200px;
    bottom:110px;
    top: 300px;
    /*background-color:#fff;
    color:#14315E;*/
    border-radius:0px;
    text-align:center;
  font-size:30px;
    /*box-shadow: 2px 2px 3px #999;*/
 
  margin-left: 88%;
}

.float{
    position:fixed;
    width:60px;
    height:60px;
    bottom:110px;
    
    color:#FFF;
    border-radius:50px;
    text-align:center;
  font-size:30px;
   /* box-shadow: 2px 2px 3px #999;*/
  z-index:100;
  margin-left: 87%;
}

.my-float{
    margin-top:16px;
}
* {
    margin: 0;
    padding: 0;
}
    }

    @media only screen and (min-width: 701px) and (max-width: 1367px){
.pooja{

    margin-left: 585px;
     margin-top: 20px;
   
}
.pooja1{

    margin-left: 465px;
     margin-top: 20px;
   
}

      .float-right .float{
      position:fixed;
   width: 100px;
   height: 100px;
    bottom:110px;
    top: 250px;
    /*background-color:#fff;
    color:#14315E;*/
    border-radius:0px;
    text-align:center;
  font-size:30px;
    /*box-shadow: 2px 2px 3px #999;*/
 
  margin-left: 93%;
}
.float{
    position:fixed;
    width:60px;
    height:60px;
    bottom:110px;
    
    color:#FFF;
    border-radius:50px;
    text-align:center;
  font-size:30px;
   /* box-shadow: 2px 2px 3px #999;*/
  z-index:100;
  margin-left: 95%;
}

.my-float{
    margin-top:16px;
}
* {
    margin: 0;
    padding: 0;
}

    }

.float1 {
    position: fixed;
    width: 60px;
    height: 60px;
    bottom: 10px;
    background-color: #25d36600;
    color: #FFF;
    border-radius: 50px;
    text-align: center;
    font-size: 30px;
    box-shadow: 2px 2px 3px #9990;
    z-index: 100;
    margin-left: 85%;
}


</style>
<style type="text/css">
    
    @media only screen and (min-width: 600px)
     {
 .call {
   display:none;
}
}
</style>

    </head>

    <body id="home" data-spy="scroll" data-offset="70">


         <a href="https://api.whatsapp.com/send?phone=+919890995658&text=I am interested in Amrutwel Property, ping me for further details." class="float" style="
    background-color:#25d366;" target="_blank">
    <img src="assets/img/whatsapp.png">
                    <i class="fa fa-whatsapp my-float"></i>
                    </a>
               <a href="tel:+919890995658" class="float1 call" target="_blank">

                    <img src="assets/img/call.png" >
                    

                  </a>
       

        <!-- Start Navbar Area -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="index.php">
                <img src="assets/img/logo.png" alt="logo">
                <img src="assets/img/logo2.png" alt="logo">
            </a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="#home">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="#details">Details</a></li>
                    <li class="nav-item"><a class="nav-link" href="#gallery">Gallery</a></li>
                   
                    <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
                </ul>
            </div>
        </nav>
        <!-- End Navbar Area -->

        <!-- Start Main Banner -->
        <section class="home-area">
            <div class="swiper-container home-slides">
                <div class="swiper-wrapper">
                    <div class="swiper-slide main-banner item-bg1">
                        <div class="d-table">
                            <div class="d-table-cell">
                                <div class="container">
                                    <div class="main-banner-content">
                                        <h1>South Grafield Street for sale <span>$6,575,000</span></h1>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>

                                        <a href="javascript:;" data-toggle="modal" data-target="#login" 
                                               class="default-btn">View Details</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="swiper-slide main-banner item-bg2">
                        <div class="d-table">
                            <div class="d-table-cell">
                                <div class="container">
                                    <div class="main-banner-content">
                                        <h1>South Grafield Street for sale <span>$6,575,000</span></h1>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>

                                        <a href="javascript:;" data-toggle="modal" data-target="#login" 
                                               class="default-btn">View Details</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="swiper-slide main-banner item-bg3">
                        <div class="d-table">
                            <div class="d-table-cell">
                                <div class="container">
                                    <div class="main-banner-content">
                                        <h1>South Grafield Street for sale <span>$6,575,000</span></h1>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>

                                        <a href="javascript:;" data-toggle="modal" data-target="#login" 
                                               class="default-btn">View Details</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="swiper-pagination"></div>
            </div>
        </section>
        <!-- End Main Banner -->

          <!-- Start Features Area -->
        <section class="features-area ptb-100 bg-f9f9f9">
            <div class="container">
                <div class="section-title">
                    <h2>Our Features</h2>
                    
                </div>

                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="single-features">
                            <div class="icon">
                                <i class="icofont-tree"></i>
                            </div>
                            <h3>Nature All Around You</h3>
                            <p>Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis.</p>

                            <a  href="javascript:;" data-toggle="modal" data-target="#login">Know More <i class="icofont-bubble-right"></i></a>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <div class="single-features">
                            <div class="icon">
                                <i class="icofont-police-car-alt-2"></i>
                            </div>
                            <h3>Get Free Parking Place</h3>
                            <p>Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis.</p>
                            
                            <a href="javascript:;" data-toggle="modal" data-target="#login">Know More <i class="icofont-bubble-right"></i></a>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 offset-lg-0 offset-md-3">
                        <div class="single-features">
                            <div class="icon">
                                <i class="icofont-ssl-security"></i>
                            </div>
                            <h3>24/7 Security</h3>
                            <p>Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis.</p>
                            
                            <a href="javascript:;" data-toggle="modal" data-target="#login">Know More <i class="icofont-bubble-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Features Area -->

        <!-- Start About Area -->
        <section id="about" class="about-area ptb-100">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-5 col-md-12">
                        <div class="about-image">
                            <img src="assets/img/about-img1.jpg" alt="about-image">
                            <img src="assets/img/layer.png" class="back-img1" alt="layer">
                            <img src="assets/img/layer.png" class="back-img2" alt="layer">
                            <img src="assets/img/circle-img.jpg" class="circle-img" alt="circle-image">
                        </div>
                    </div>

                    <div class="col-lg-7 col-md-12">
                        <div class="about-content">
                            <h3>All about of this property</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida.</p>

                            <div class="about-inner">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6">
                                        <div class="single-inner-box">
                                            <div class="icon">
                                                <i class="icofont-building-alt"></i>
                                            </div>
                                            <h4>Built in 1976</h4>
                                            <p>Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel.</p>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6">
                                        <div class="single-inner-box">
                                            <div class="icon">
                                                <i class="icofont-bed"></i>
                                            </div>
                                            <h4>6 Beds</h4>
                                            <p>Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel.</p>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6">
                                        <div class="single-inner-box">
                                            <div class="icon">
                                                <i class="icofont-bathtub"></i>
                                            </div>
                                            <h4>5 Baths</h4>
                                            <p>Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel.</p>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6">
                                        <div class="single-inner-box">
                                            <div class="icon">
                                                <i class="icofont-beach-bed"></i>
                                            </div>
                                            <h4>2 Pools</h4>
                                            <p>Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel.</p>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6">
                                        <div class="single-inner-box">
                                            <div class="icon">
                                                <i class="icofont-car-alt-4"></i>
                                            </div>
                                            <h4>3 Parking</h4>
                                            <p>Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel.</p>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6">
                                        <div class="single-inner-box">
                                            <div class="icon">
                                                <i class="icofont-building"></i>
                                            </div>
                                            <h4>2 Floors</h4>
                                            <p>Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel.</p>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6">
                                        <div class="single-inner-box">
                                            <div class="icon">
                                                <i class="icofont-hotel"></i>
                                            </div>
                                            <h4>2475 Sqft</h4>
                                            <p>Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel.</p>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6">
                                        <div class="single-inner-box">
                                            <div class="icon">
                                                <i class="icofont-island"></i>
                                            </div>
                                            <h4>Lot 0.5 Acres</h4>
                                            <p>Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End About Area -->

        <!-- Start Property Details Area -->
        <section id="details" class="property-details-area">
            <div class="container-fluid p-0">
                <div class="row m-0">
                    <div class="col-lg-6 col-md-12 p-0">
                        <div class="video-image">
                            <img src="assets/img/video-bg.jpg" alt="image">

                            <a href="javascript:;" data-toggle="modal" data-target="#login"  class="video-btn "><i class="icofont-ui-play"></i></a>
                            
                        </div>
                    </div>

                    <div class="col-lg-6 col-md-12 p-0">
                        <div class="property-details-info">
                            <div class="property-details">
                                <h3>Property Details</h3>

                                <ul>
                                    <li>Listing Type: <span>Single Family</span></li>
                                    <li>Listing ID: <span>5566128</span></li>
                                    <li>Bedrooms: <span>5</span></li>
                                    <li>Bathrooms: <span>7</span></li>
                                    <li>House Size: <span>7,965 sqft</span></li>
                                    <li>Lot Size: <span>8,276.00 sqft</span></li>
                                    <li>Listing Status: <span>Active</span></li>
                                    <li>Year Built: <span>1911</span></li>
                                    <li>Tazes: <span>18252.0</span></li>
                                    <li>Tax Year: <span>2018</span></li>
                                </ul>
                            </div>

                            <div class="additional-details">
                                <h3>Additional Details</h3>
                                
                                <ul>
                                    <li>Fuel: <span>Electric, Gas</span></li>
                                    <li>Construction Type: <span>Brick, Frame</span></li>
                                    <li>Fireplace Location: <span>Bedrooom</span></li>
                                    <li>Roof: <span>Composition Shingles</span></li>
                                    <li>Fireplace: <span>Wood</span></li>
                                    <li>Lot Size: <span>8,276.00 sqft</span></li>
                                    <li>Interitor Features: <span>Kitchen</span></li>
                                    <li>Road Surface: <span>Paven Road</span></li>
                                    <li>Sale Rent: <span>For Sale</span></li>
                                    <li>Seller: <span>Individual</span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Property Details Area -->

        <!-- Start Photo Gallery Area -->
        <section id="gallery" class="photo-gallery-area ptb-100 pb-0">
            <div class="container">
                <div class="section-title">
                    <h2>Photo Gallery</h2>
                  
                </div>
            </div>

            <div class="row m-0">
                <div class="col-lg-6 col-md-12 p-0">
                    <div class="photo-gallery-item">
                        <a href="assets/img/gallery-img1.jpg" class="popup-btn"><img src="assets/img/gallery-img1.jpg" alt="image"></a>
                    </div>
                </div>

                <div class="col-lg-6 col-md-12 p-0">
                    <div class="row m-0">
                        <div class="col-lg-6 col-sm-6 col-md-6 p-0">
                            <div class="photo-gallery-item">
                                <a href="assets/img/gallery-img2.jpg" class="popup-btn"><img src="assets/img/gallery-img2.jpg" alt="image"></a>
                            </div>
                        </div>

                        <div class="col-lg-6 col-sm-6 col-md-6 p-0">
                            <div class="photo-gallery-item">
                                <a href="assets/img/gallery-img3.jpg" class="popup-btn"><img src="assets/img/gallery-img3.jpg" alt="image"></a>
                            </div>
                        </div>

                        <div class="col-lg-12 col-sm-12 col-md-12 p-0">
                            <div class="photo-gallery-item">
                                <a href="assets/img/gallery-img4.jpg" class="popup-btn"><img src="assets/img/gallery-img4.jpg" alt="image"></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-md-12 p-0">
                    <div class="photo-gallery-item">
                        <a href="assets/img/gallery-img5.jpg" class="popup-btn"><img src="assets/img/gallery-img5.jpg" alt="image"></a>
                    </div>
                </div>

                <div class="col-lg-3 col-sm-6 col-md-6 p-0">
                    <div class="photo-gallery-item">
                        <a href="assets/img/gallery-img6.jpg" class="popup-btn"><img src="assets/img/gallery-img6.jpg" alt="image"></a>
                    </div>
                </div>

                <div class="col-lg-3 col-sm-6 col-md-6 p-0">
                    <div class="photo-gallery-item">
                        <a href="assets/img/gallery-img7.jpg" class="popup-btn"><img src="assets/img/gallery-img7.jpg" alt="image"></a>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Photo Gallery Area -->
         <!-- Start Floor Plans Area -->
        <section class="floor-plans-area ptb-100">
            <div class="container">
                <div class="section-title">
                    <h2>Floor Plans</h2>
                   
                </div>

                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="tab">
                            <ul class="tabs">
                                <li><a href="#">
                                    Floor 1
                                </a></li>
                                
                                <li><a href="#">
                                    Floor 2
                                </a></li>

                                <li><a href="#">
                                    Floor 3
                                </a></li>

                                <li><a href="#">
                                    Floor 4
                                </a></li>

                                <li><a href="#">
                                    Floor 5
                                </a></li>
                            </ul>

                            <div class="tab_content">
                                <div class="tabs_item">
                                    <div class="row align-items-center">
                                        <div class="col-lg-6 col-md-12 content">
                                            <div class="tabs_item_content">
                                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.</p>

                                                <ul>
                                                    <li>Floor No <span>1</span></li>
                                                    <li>Rooms <span>4</span></li>
                                                    <li>Total Area <span>311.50 sqft</span></li>
                                                    <li>Bathroom <span>Yes</span></li>
                                                    <li>Windows <span>4</span></li>
                                                </ul>
 <a href="javascript:;" data-toggle="modal" data-target="#login" 
                                               class="default-btn">Schedule a Visit</a>
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-12 image">
                                            <div class="tabs_item_image">
                                                <img src="assets/img/floor-img1.png" alt="image">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="tabs_item">
                                    <div class="row align-items-center">
                                        <div class="col-lg-6 col-md-12 image">
                                            <div class="tabs_item_image">
                                                <img src="assets/img/floor-img2.png" alt="image">
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-12 content">
                                            <div class="tabs_item_content">
                                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.</p>

                                                <ul>
                                                    <li>Floor No <span>2</span></li>
                                                    <li>Rooms <span>3</span></li>
                                                    <li>Total Area <span>301.50 sqft</span></li>
                                                    <li>Bathroom <span>Yes</span></li>
                                                    <li>Windows <span>3</span></li>
                                                </ul>

                                               <a href="javascript:;" data-toggle="modal" data-target="#login" 
                                               class="default-btn">Schedule a Visit</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="tabs_item">
                                    <div class="row align-items-center">
                                        <div class="col-lg-6 col-md-12 content">
                                            <div class="tabs_item_content">
                                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.</p>

                                                <ul>
                                                    <li>Floor No <span>3</span></li>
                                                    <li>Rooms <span>4</span></li>
                                                    <li>Total Area <span>311.50 sqft</span></li>
                                                    <li>Bathroom <span>Yes</span></li>
                                                    <li>Windows <span>4</span></li>
                                                </ul>

                                                <a href="javascript:;" data-toggle="modal" data-target="#login" 
                                               class="default-btn">Schedule a Visit</a>
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-12 image">
                                            <div class="tabs_item_image">
                                                <img src="assets/img/floor-img3.png" alt="image">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="tabs_item">
                                    <div class="row align-items-center">
                                        <div class="col-lg-6 col-md-12 image">
                                            <div class="tabs_item_image">
                                                <img src="assets/img/floor-img4.png" alt="image">
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-12 content">
                                            <div class="tabs_item_content">
                                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.</p>

                                                <ul>
                                                    <li>Floor No <span>4</span></li>
                                                    <li>Rooms <span>4</span></li>
                                                    <li>Total Area <span>311.50 sqft</span></li>
                                                    <li>Bathroom <span>Yes</span></li>
                                                    <li>Windows <span>4</span></li>
                                                </ul>

                                                <a href="#" class="default-btn">Schedule a Visit</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="tabs_item">
                                    <div class="row align-items-center">
                                        <div class="col-lg-6 col-md-12 content">
                                            <div class="tabs_item_content">
                                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’s standard dummy text ever since the 1500s.</p>

                                                <ul>
                                                    <li>Floor No <span>5</span></li>
                                                    <li>Rooms <span>4</span></li>
                                                    <li>Total Area <span>311.50 sqft</span></li>
                                                    <li>Bathroom <span>Yes</span></li>
                                                    <li>Windows <span>4</span></li>
                                                </ul>

                                                <a href="#" class="default-btn">Schedule a Visit</a>
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-12 image">
                                            <div class="tabs_item_image">
                                                <img src="assets/img/floor-img5.png" alt="image">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Floor Plans Area -->




       



        <!-- Start Map Area -->
       <div class="mapouter"><div class="gmap_canvas"><iframe width="100%" height="500" id="gmap_canvas" src="https://maps.google.com/maps?q=amrutwell%20arje%20malwadi&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://www.emojilib.com/divi-discount-code-elegant-themes-coupon/"></a></div><style>.mapouter{position:relative;text-align:right;height:500px;width:100%;}.gmap_canvas {overflow:hidden;background:none!important;height:500px;width:100%;}</style></div>
        <!-- End Map Area -->

        <!-- Start Contact Area -->
        <section id="contact" class="contact-area ptb-100">
            <div class="container">
                <div class="section-title">
                    <h2>Get in Touch</h2>
                   
                </div>

                <div class="row">
                    <div class="col-lg-5 col-md-12">
                        <div class="contact-box">
                            <div class="agent-contact">
                                <div class="image">
                                    <img src="assets/img/contact-agent.jpg" alt="image">
                                </div>

                                <div class="content">
                                    
                                    <p>Amrutwell Society, Warje, Pune, Maharashtra 411058</p>
                                </div>
                            </div>

                            <ul class="contact-info">
                                <li><i class="icofont-phone-circle"></i> <a href="tel:+919890995658">+91 9890 9956 58</a></li>
                                <li><i class="icofont-fax"></i> <a  href="tel:02025217070">020 25217070</a></li>
                                <li><i class="icofont-envelope"></i> <a href="mailto:prathameshdev@gmail.com">prathameshdev@gmail.com</a></li>
                               
                            </ul>

                           <!--  <ul class="social">
                                <li><a href="#"><i class="icofont-facebook"></i></a></li>
                                <li><a href="#"><i class="icofont-twitter"></i></a></li>
                                <li><a href="#"><i class="icofont-linkedin"></i></a></li>
                                <li><a href="#"><i class="icofont-instagram"></i></a></li>
                            </ul> -->
                        </div>
                    </div>

                     <div class="col-md-6">
                       
                            <div class="">
                                <form action="thank.php" method="POST" >
                                  
                                        <div class="form-group">
                                       
                                         <input name="name" type="text" id="name" placeholder="Your Name" required="required" class="form-control"/>
                                        
                                   
                                </div>

                               
                                    <div class="form-group">
                                        
                                      <input name="phone" type="text" id="mobile" placeholder="Mobile No." required="required" class="form-control"/>
                                       
                                  
                                </div>

                             
                                    <div class="form-group">
                                        
                                     <input name="email" type="email" id="email" placeholder="Email Address" pattern="^[A-Za-z0-9](([_\.\-]?[a-zA-Z0-9]+)*)@([A-Za-z0-9]+)(([\.\-]?[a-zA-Z0-9]+)*)\.([A-Za-z]{2,})$" required="required" class="form-control" />
                                       
                         
                                </div>

                            
                                    <div class="form-group">
                                       
                                       <textarea name="message" cols="40" rows="3" id="comments" placeholder="Message" spellcheck="true" required="required" class="form-control"></textarea>
                                        
                                 
                                </div>

                                <div class="col-lg-12 col-md-12">
                                   
                                  <input type="submit" class="submit button btn btn-info" id="submit" name="submit" value="Submit Message" style="background-color: #71b100" />
                                </div>
                            </form>
                        </div>

                        
                    </div>
                </div>
            </div>
        </section>
        <!-- End Contact Area -->

 <!-- BEGIN: CONTENT/USER/LOGIN-FORM -->
<div class="modal fade c-content-login-form" id="login" role="dialog">
    <div class="modal-dialog">
      
          
             <!-- Modal content-->
      <div class="modal-content row">
        <div class="modal-header1 custom-modal-header">
          <button type="button" class="close" data-dismiss="modal">×</button>
          <h4 class="modal-title" style="color: #71b100;font-weight:bold">Enquire Now</h4>
        </div>
            <div class="modal-body">
                 <form name="info_form" class="form-inline" action="thank.php" method="post">
            <div class="form-group col-sm-12">
              <input type="text" class="form-control" name="name" id="name" placeholder="Enter Name" required / style="border: 3px solid #71b100;font-weight:bold">
            </div>

    <div class="form-group col-sm-12">
              <input type="text" class="form-control" name="phone" id="phone" placeholder="Enter Phone" pattern="[0-9]{10}" maxlength="10" required / style="border: 3px solid #71b100;font-weight:bold">
            </div>

            <div class="form-group col-sm-12">
              <input type="email" class="form-control" name="email" id="email" placeholder="Enter Email" required / style="border: 3px solid #71b100;font-weight:bold">
            </div>
          
          
            
            <div class="form-group col-sm-12">
            <!--  <textarea class="form-control" id="msg" name="message" rows="4" placeholder="Enter Message"></textarea>-->
            <input type="text" class="form-control" name="message" id="message" placeholder="Enter Message" required / style="border: 3px solid #71b100;font-weight:bold">
            </div>
            <div class="form-group col-sm-12">
              <button type="submit" name="submit" class="btn btn-danger pull-right" style="background-color: #71b100"><i class="fa fa-send"></i> Submit</button></br>
            </div>
          </form>
           
          </div>
        </div>
    </div>
</div><!-- END: CONTENT/USER/LOGIN-FORM -->
<style type="text/css">
  #enquirypopup .modal-dialog:before {
    content: '';
    height: 0px;
    width: 0px;
    border-left: 50px solid #17B6BB;
    border-right: 50px solid transparent;
    border-bottom: 50px solid transparent;
    position: absolute;
    top: 1px;
    left: -14px;
    z-index: 99;
    /*display: none;*/
}

#enquirypopup .modal-dialog:after {
    content: '';
    height: 0px;
    width: 0px;
    border-left: 50px solid #17B6BB;
    border-right: 50px solid transparent;
    border-bottom: 50px solid transparent;
    position: absolute;
    top: 1px;
    left: -14px;
    z-index: 99;
     /*display: none;*/
}
}


#enquirypopup .modal-dialog {
    width: 300px;
    padding: 0px ;
    position: relative;
}


 @media only screen and (max-width: 600px)
     {
#enquirypopup .modal-dialog {
    width: 94%;
    padding: 20px;
    position: relative;
}

.modal-open .modal {
    overflow-x: hidden;
    overflow-y: auto;
    top: 15%;
}
#enquirypopup .modal-dialog .close {
    z-index: 99999999;
    color: #ed6b75;
    text-shadow: 0px 0px 0px;
    font-weight: normal;
    top: 18px;
    right: 6px;
    left: 263px;
    position: absolute;
    opacity: 1;
}
}

#enquirypopup .modal-dialog:before {
    content: '';
    height: 0px;
    width: 0px;
    border-left: 50px solid #17B6BB;
    border-right: 50px solid transparent;
    border-bottom: 50px solid transparent;
    position: absolute;
    top: 1px;
    left: -14px;
    z-index: 99;
}

.custom-modal-header {
    text-align: center;
    color: #14315E;
    text-transform: uppercase;
    letter-spacing: 2px;
    border-top: 4px solid;
}

#enquirypopup .modal-dialog .close {
    z-index: 99999999;
    color: #ed6b75;
    text-shadow: 0px 0px 0px;
    font-weight: normal;
    top: 18px;
    right: 169px;
    position: absolute;
    opacity: 1;
}

.custom-modal-header .modal-title {
    /* font-weight: bold; */
    font-size: 18px;
}

#enquirypopup .modal-dialog:after {
    content: '';
    height: 0px;
    width: 0px;
    /* border-right: 50px solid rgba(255, 0, 0, 0.98); */
    border-right: 50px solid #17b6bb;
    border-bottom: 50px solid transparent;
    position: absolute;
    top: 1px;
    right: -14px;
    z-index: 999999;
   
}

.form-group {
    margin-bottom: 15px !important;
}

.form-inline .form-control {
    display: inline-block;
    width: 100%;
    vertical-align: middle;
}


#enquirypopup .modal-dialog:before {
    content: '';
    height: 0px;
    width: 0px;
    /*border-left: 50px solid #17B6BB;*/
    border-right: 50px solid transparent;
    border-bottom: 50px solid transparent;
    position: absolute;
    top: 1px;
    left: -14px;
    z-index: 99;
     display: none;
}

#enquirypopup .modal-dialog:after {
    content: '';
    height: 0px;
    width: 0px;
    /*border-right: 50px solid #17B6BB;*/
    border-right: 50px solid transparent;
    border-bottom: 50px solid transparent;
    position: absolute;
    top: 1px;
    left: -14px;
    z-index: 99;
    display:none;
}

</style>


        <!-- Start Footer Area -->
        <footer class="footer-area">
            <div class="container">
                <p><i class="icofont-copyright"></i> <a href="https://webocto.com/">WebOcto</a>. All Rights Reserved, 2020</p>
            </div>
        </footer>
        <!-- End Footer Area -->

       
        
        <!-- JQuery Min JS -->
        <script src="assets/js/jquery.min.js"></script>
        <!-- Popper Min JS -->
        <script src="assets/js/popper.min.js"></script>
        <!-- Bootstrap Min JS -->
        <script src="assets/js/bootstrap.min.js"></script>
        <!-- Swiper Min JS -->
        <script src="assets/js/swiper.min.js"></script>
        <!-- Magnific Popup Min JS -->
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
        <!-- WOW Min JS -->
        <script src="assets/js/wow.min.js"></script>
        <!-- Form Validator Min JS -->
        <script src="assets/js/form-validator.min.js"></script>
        <!-- Contact Form Min JS -->
        <script src="assets/js/contact-form-script.js"></script>
        <!-- Map API JS FILES -->
        <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyApghCIIx9MpQhA768sKXxvR_Okg0SF2k4&callback=initMap"></script>
		<!-- Holsworthy Map JS FILE -->
        <script src="assets/js/holsworthy-map.js"></script>
        <!-- Main JS -->
        <script src="assets/js/main.js"></script>
    </body>

</html>