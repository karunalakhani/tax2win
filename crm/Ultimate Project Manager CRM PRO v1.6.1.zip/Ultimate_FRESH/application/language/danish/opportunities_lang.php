<?php
$lang['opportunities'] = 'Muligheder';
$lang['opportunities_state_reason'] = 'Muligheder State Årsag';
$lang['opportunities_state'] = 'Muligheder stat';
$lang['stages'] = 'Niveauer';
$lang['won'] = 'forladt';
$lang['abandoned'] = 'forladt';
$lang['suspended'] = 'Faret vild';
$lang['lost'] = 'Faret vild';
$lang['negotiation'] = 'Forhandling';
$lang['update'] = 'Opdatering';
$lang['all_opportunities'] = 'Alle Muligheder';
$lang['new_opportunities'] = 'Nye muligheder';
$lang['opportunity_name'] = 'Nye muligheder';
$lang['qualification'] = 'Nye muligheder';
$lang['proposition'] = 'Nye muligheder';
$lang['dead'] = 'Nye muligheder';
$lang['probability'] = 'Nye muligheder';
$lang['close_date'] = 'Nye muligheder';
$lang['who_responsible'] = 'Nye muligheder';
$lang['expected_revenue'] = 'Nye muligheder';
$lang['new_link'] = 'Nye muligheder';
$lang['next_action'] = 'Nye muligheder';
$lang['next_action_date'] = 'Nye muligheder';
$lang['current_state'] = 'Nye muligheder';
$lang['change_state'] = 'Nye muligheder';
$lang['opportunity_details'] = 'Nye muligheder';
$lang['activity_update_opportunity'] = 'Nye muligheder';
$lang['update_opportunity'] = 'Nye muligheder';
$lang['activity_save_opportunity'] = 'Nye muligheder';
$lang['save_opportunity'] = 'Nye muligheder';
$lang['save_opportunity_call'] = 'Nye muligheder';
$lang['activity_save_opportunity_call'] = 'Nye muligheder';
$lang['activity_update_opportunity_call'] = 'Nye muligheder';
$lang['update_opportunity_call'] = 'Nye muligheder';
$lang['activity_opportunity_call_deleted'] = 'Nye muligheder';
$lang['opportunity_call_deleted'] = 'Nye muligheder';
$lang['save_opportunity_metting'] = 'Nye muligheder';
$lang['activity_save_opportunity_metting'] = 'Nye muligheder';
$lang['activity_update_opportunity_metting'] = 'Nye muligheder';
$lang['update_opportunity_metting'] = 'Nye muligheder';
$lang['activity_opportunity_metting_deleted'] = 'Nye muligheder';
$lang['opportunity_metting_deleted'] = 'Nye muligheder';
$lang['activity_new_opportunity_comment'] = 'Nye muligheder';
$lang['opportunity_comment_save'] = 'Nye muligheder';
$lang['task_comment_deleted'] = 'Nye muligheder';
$lang['opportunity_file_updated'] = 'Nye muligheder';
$lang['opportunity_file_added'] = 'Nye muligheder';
$lang['activity_new_opportunity_attachment'] = 'Nye muligheder';
$lang['opportunity_attachfile_deleted'] = 'Nye muligheder';
$lang['activity_opportunity_attachfile_deleted'] = 'Nye muligheder';
$lang['opportunity_deleted'] = 'Nye muligheder';
$lang['activity_opportunity_deleted'] = 'Opportunity oplysninger slettet';


/* End of file opportunities_lang.php */
/* Location: ./application/language/danish/opportunities_lang.php */
