<?php
$lang['menu_permission'] = 'Menu Tilladelse';
$lang['module'] = 'Menu Tilladelse';
$lang['department_update'] = 'Department Infromation Succesfuld opdatering';
$lang['designation_info_deleted'] = 'Betegnelse Infromation slettet';
$lang['no_designation_create_yet'] = 'Ingen Betegnelse Opret endnu';
$lang['department_already_used'] = 'Institut Information Allerede Bruges';
$lang['undefined_department'] = 'Institut Information Allerede Bruges';
$lang['activity_update_a_department'] = 'Institut Information Allerede Bruges';
$lang['activity_delete_a_department'] = 'Institut Information Allerede Bruges';
$lang['activity_delete_a_designation'] = 'Institut Information Allerede Bruges';


/* End of file departments_lang.php */
/* Location: ./application/language/danish/departments_lang.php */
