<?php
$lang['opportunities'] = ' Des opportunités      ';
$lang['opportunities_state_reason'] = '  Opportunités État Raison';
$lang['opportunities_state'] = ' Opportunités État   Étapes';
$lang['stages'] = '   A gagné   Abandonné   Suspendu   Perdu   Négociation   Mettre à jour   Toutes les chances   Nouvelles opportunités   Nom de l\'opportunité   Qualification   Proposition   Mort   Probabilité de gagner   Prévisions Date de fermeture   Qui est responsable   Revenu prévu   Ajouter un nouveau lien   Next action   Action suivante Date   État actuel   Modifier l\'état   Détails Opportunity   Mise à jour Opportunity deatils   l\'information mise à jour Opportunité avec succès   Enregistrer Opportunity deatils   Enregistrer les informations Opportunité avec succès   Enregistrer Opportunité d\'informations Appel avec succès   Enregistrer Opportunité Appel deatils   Mise à jour Opportunité Appel deatils   Mise à jour de l\'information Possibilité d\'appel avec succès   Opportunité Appel supprimé   informations Opportunité d\'appel supprimé avec succès!   Enregistrer les informations Opportunity Mettings avec succès   Enregistrer Opportunity Mettings deatils   Mise à jour Opportunity Mettings deatils   l\'information mise à jour Opportunity Mettings avec succès   Opportunity Mettings Supprimé   informations Opportunity Mettings supprimé avec succès!   Opportunity New Commentaire ajouté!   Opportunité d\'informations Commentaire enregistré avec succès!   Informations Commentaire supprimé avec succès   Informations sur le fichier de mise à jour avec succès Opportunity   Informations sur les fichiers d\'opportunité avec succès Ajouté   Opportunité fichier Ajouté   Opportunité fichier supprimé   Opportunité fichier supprimé   informations d\'opportunité avec succès supprimé   informations d\'opportunité Supprimé';
$lang['won'] = ' ';
$lang['abandoned'] = ' ';
$lang['suspended'] = ' ';
$lang['lost'] = ' ';
$lang['negotiation'] = ' ';
$lang['update'] = ' ';
$lang['all_opportunities'] = ' ';
$lang['new_opportunities'] = ' ';
$lang['opportunity_name'] = ' ';
$lang['qualification'] = ' ';
$lang['proposition'] = ' ';
$lang['dead'] = ' ';
$lang['probability'] = ' ';
$lang['close_date'] = ' ';
$lang['who_responsible'] = ' ';
$lang['expected_revenue'] = ' ';
$lang['new_link'] = ' ';
$lang['next_action'] = ' ';
$lang['next_action_date'] = ' ';
$lang['current_state'] = ' ';
$lang['change_state'] = ' ';
$lang['opportunity_details'] = ' ';
$lang['activity_update_opportunity'] = ' ';
$lang['update_opportunity'] = ' ';
$lang['activity_save_opportunity'] = ' ';
$lang['save_opportunity'] = ' ';
$lang['save_opportunity_call'] = ' ';
$lang['activity_save_opportunity_call'] = ' ';
$lang['activity_update_opportunity_call'] = ' ';
$lang['update_opportunity_call'] = ' ';
$lang['activity_opportunity_call_deleted'] = ' ';
$lang['opportunity_call_deleted'] = ' ';
$lang['save_opportunity_metting'] = ' ';
$lang['activity_save_opportunity_metting'] = ' ';
$lang['activity_update_opportunity_metting'] = ' ';
$lang['update_opportunity_metting'] = ' ';
$lang['activity_opportunity_metting_deleted'] = ' ';
$lang['opportunity_metting_deleted'] = ' ';
$lang['activity_new_opportunity_comment'] = ' ';
$lang['opportunity_comment_save'] = ' ';
$lang['task_comment_deleted'] = ' ';
$lang['opportunity_file_updated'] = ' ';
$lang['opportunity_file_added'] = ' ';
$lang['activity_new_opportunity_attachment'] = ' ';
$lang['opportunity_attachfile_deleted'] = ' ';
$lang['activity_opportunity_attachfile_deleted'] = ' ';
$lang['opportunity_deleted'] = ' ';
$lang['activity_opportunity_deleted'] = ' ';


/* End of file opportunities_lang.php */
/* Location: ./application/language/french/opportunities_lang.php */
