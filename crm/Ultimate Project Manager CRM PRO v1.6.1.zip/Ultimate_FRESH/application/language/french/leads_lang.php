<?php
$lang['recent_leads'] = ' Leads récents';
$lang['source'] = 'La source';
$lang['facebook_profile_link'] = ' Facebook URL';
$lang['twitter_profile_link'] = ' Twitter URL';
$lang['linkedin_profile_link'] = ' Linkedin URL';
$lang['leads_name'] = 'Leads Nom';
$lang['mettings_deleted'] = ' informations Mettings avec succès supprimé';
$lang['convert'] = ' Convertir';
$lang['convert_to_client'] = ' Convertir au client';
$lang['activity_convert_to_client'] = 'Convertir Lead Pour client';
$lang['convert_to_client_suucess'] = 'Convertir Lead Pour client avec succès';
$lang['import_leads'] = ' Leads d\'importation';


/* End of file leads_lang.php */
/* Location: ./application/language/french/leads_lang.php */
