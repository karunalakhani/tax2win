<?php
$lang['client_list'] = ' Liste de clients';
$lang['all_client'] = ' Tous les clients';
$lang['name'] = 'prénom';
$lang['client'] = ' Client';
$lang['clients'] = ' Clients';
$lang['client_status'] = ' Sélectionner le genre';
$lang['select'] = 'Sélectionner';
$lang['manage_client'] = ' Gérer client';
$lang['clients_registration'] = ' Clients Enregistrements';
$lang['clients_registered'] = ' Clients enregistrés';
$lang['client_registered_successfully'] = ' enregistrement réussi client !';
$lang['activity_added_new_company'] = ' Ajouter un nouveau client';
$lang['activity_update_company'] = 'Mettre à jour nouveau client';
$lang['activity_update_contact'] = 'Mettre à jour nouveau contact';
$lang['activity_added_new_contact'] = 'Ajouter un nouveau contact';
$lang['activity_deleted_contact'] = ' Effacer le contact';
$lang['delete_contact'] = 'Client Informations de contact a bien été supprimé !';
$lang['activity_deleted_client'] = ' supprimé client';
$lang['delete_client'] = ' Renseignements sur le client a bien été supprimé !';
$lang['select_type'] = 'Sélectionner le genre';
$lang['client_contact'] = ' Contact';
$lang['hosting'] = ' Hébergement';
$lang['converted_from'] = ' Formulaire Converti';
$lang['without_converted'] = 'Sans converti';
$lang['converted_client'] = ' Ancien client';


/* End of file client_lang.php */
/* Location: ./application/language/french/client_lang.php */
