<?php
$lang['menu_permission'] = '菜单权限';
$lang['module'] = '模';
$lang['department_update'] = '部Infromation成功更新';
$lang['designation_info_deleted'] = '名称Infromation已成功删除';
$lang['no_designation_create_yet'] = '无名称尚未创建';
$lang['department_already_used'] = '部信息已被使用';
$lang['undefined_department'] = '未定义部';
$lang['activity_update_a_department'] = '更新部';
$lang['activity_delete_a_department'] = '删除部';
$lang['activity_delete_a_designation'] = '名称已删除';


/* End of file departments_lang.php */
/* Location: ./application/language/chinese/departments_lang.php */
