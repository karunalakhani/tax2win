<?php
$lang['performance'] = 'أداء';
$lang['performance_indicator'] = 'مؤشر';
$lang['give_appraisal'] = 'إعطاء تقييم';
$lang['performance_report'] = 'تقرير الأداء';
$lang['indicator_list'] = 'قائمة مؤشر';
$lang['set_indicator'] = 'مجموعة المؤشر';
$lang['technical_competency'] = 'الكفاءات الفنية';
$lang['customer_experience_management'] = 'إدارة تجربة العملاء';
$lang['beginner'] = 'مبتدئ';
$lang['intermediate'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['advanced'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['expert_leader'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['marketing'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['management'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['administration'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['presentation_skill'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['quality_of_work'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['efficiency'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['behavioural_competency'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['integrity'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['professionalism'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['team_work'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['critical_thinking'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['conflict_management'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['attendance'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['ability_to_meet_deadline'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['activity_performance_indicator_saved'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['activity_performance_indicator_updated'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['indicator_update'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['indicator_saved'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['performance_indicator_details'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['indicator_value_not_set'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['give_performance_appraisal'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['remarks'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['expected_value'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['set_value'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['not_set'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['appraisal_already_provided'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['activity_appraisal_update'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['activity_appraisal_saved'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['appraisal_update'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['appraisal_saved'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['emp_id'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['appraisal_month'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['performance_appraisal_details'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['performance_appraisal_of'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['assigned'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['expected'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';
$lang['atleast_one_appraisal'] = 'قدمت معلومات تقييم إذا لهذا المستخدم لمرة واحدة:';


/* End of file performance_lang.php */
/* Location: ./application/language/arabic/performance_lang.php */
